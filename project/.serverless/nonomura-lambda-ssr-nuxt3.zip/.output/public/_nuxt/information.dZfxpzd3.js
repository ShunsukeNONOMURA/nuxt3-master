import{d as e,t as n,v as o}from"./entry.lzMpF_Ij.js";const i=e({__name:"information",setup(t){return(a,r)=>(n(),o("div",null,"information"))}});export{i as default};
