globalThis._importMeta_={url:import.meta.url,env:process.env};export { m as handler } from './chunks/nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
//# sourceMappingURL=index.mjs.map
