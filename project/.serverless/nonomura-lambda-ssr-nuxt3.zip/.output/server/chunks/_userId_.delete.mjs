import { d as defineEventHandler } from './nitro/aws-lambda.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const _userId__delete = defineEventHandler(async (event) => {
  const prisma = new PrismaClient();
  const userId = event.context.params.userId;
  const deleteUser = await prisma.tUser.delete({
    where: {
      userId
    }
  });
  return {
    data: { deleteUser }
  };
});

export { _userId__delete as default };
//# sourceMappingURL=_userId_.delete.mjs.map
