const client_manifest = {
  "__plugin-vue_export-helper.x3n3nnut.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.x3n3nnut.js"
  },
  "_user.rwACASJv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.rwACASJv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vue.f36acd1f.0Vxv4pmS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.0Vxv4pmS.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.1DH8SDFE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "error-404.qFGwA4uS.css"
    ],
    "file": "error-404.Ewr9cWuQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.0Vxv4pmS.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.qFGwA4uS.css": {
    "file": "error-404.qFGwA4uS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "error-500.V0P2JAtD.css"
    ],
    "file": "error-500.pZ8SIl9H.js",
    "imports": [
      "_vue.f36acd1f.0Vxv4pmS.js",
      "__plugin-vue_export-helper.x3n3nnut.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.V0P2JAtD.css": {
    "file": "error-500.V0P2JAtD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "materialdesignicons-webfont.kq_ClZaA.eot",
      "materialdesignicons-webfont.6eb_lmTU.woff2",
      "materialdesignicons-webfont.D15t_tsC.woff",
      "materialdesignicons-webfont.e5j8FT_3.ttf"
    ],
    "css": [
      "entry.8oCQzRZj.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.lzMpF_Ij.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.8oCQzRZj.css": {
    "file": "entry.8oCQzRZj.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "materialdesignicons-webfont.kq_ClZaA.eot": {
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "materialdesignicons-webfont.6eb_lmTU.woff2": {
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "materialdesignicons-webfont.D15t_tsC.woff": {
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "materialdesignicons-webfont.e5j8FT_3.ttf": {
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "pages/home.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "home.iQUwbNV5.js",
    "imports": [
      "_user.rwACASJv.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/home.vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nNLNvtQp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/information.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "information.dZfxpzd3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/information.vue"
  },
  "pages/logout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logout.EPB1xK0V.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/logout.vue"
  },
  "pages/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.cAmH1RMl.css"
    ],
    "file": "setting.PjW2j5gI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting.vue"
  },
  "setting.cAmH1RMl.css": {
    "file": "setting.cAmH1RMl.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.H0emHJs9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "pages/setting/tmp.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tmp.0QjS-qfy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/tmp.vue"
  },
  "pages/user/[userId].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_userId_.Fn4-5jI1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_user.rwACASJv.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/[userId].vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
