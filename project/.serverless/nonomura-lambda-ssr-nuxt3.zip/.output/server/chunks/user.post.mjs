import { d as defineEventHandler, r as readBody } from './nitro/aws-lambda.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

class UserFactory {
  constructor() {
  }
  create(userProps) {
    const user = userProps;
    user.userRoleId = "sample";
    return user;
  }
}
const user_post = defineEventHandler(async (event) => {
  const userFactory = new UserFactory();
  const body = await readBody(event);
  const userProps = body.user;
  const user = userFactory.create(userProps);
  const prisma = new PrismaClient();
  const createUser = await prisma.tUser.upsert({
    where: user,
    update: user,
    create: user
  });
  return {
    head: {},
    data: {
      createUser
    }
  };
});

export { user_post as default };
//# sourceMappingURL=user.post.mjs.map
