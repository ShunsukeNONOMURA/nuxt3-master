import { d as defineEventHandler } from './nitro/aws-lambda.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class UserRepository {
  static async find(userId) {
    const user = await this.prisma.tUser.findUnique({
      where: {
        userId
      }
    });
    return user;
  }
  static async delete(userId) {
    const prisma = new PrismaClient();
    const deleteUser = await prisma.tUser.delete({
      where: {
        userId
      }
    });
    return deleteUser;
  }
}
__publicField(UserRepository, "prisma", new PrismaClient());
const _userId__get = defineEventHandler(async (event) => {
  new UserRepository();
  const userId = event.context.params.userId;
  const user = await UserRepository.find(userId);
  return {
    data: {
      user
    }
  };
});

export { _userId__get as default };
//# sourceMappingURL=_userId_.get.mjs.map
