import { d as defineEventHandler, g as getQuery } from './nitro/aws-lambda.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const user_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const limit = parseInt(query.limit);
  const offset = parseInt(query.offset);
  const where = {};
  const orderBy = {};
  const prisma = new PrismaClient();
  const [items, total] = await Promise.all([
    prisma.tUser.findMany({
      where,
      take: limit,
      skip: offset,
      orderBy
    }),
    prisma.tUser.count({ where })
  ]);
  return {
    head: {
      status: "ok"
    },
    data: {
      user: {
        total,
        items
        // limit,
        // offset,
      }
    }
  };
});

export { user_get as default };
//# sourceMappingURL=user.get.mjs.map
