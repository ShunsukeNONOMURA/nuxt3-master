import { d as defineEventHandler } from './nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const health_get = defineEventHandler(async () => {
  return {
    head: {
      status: "ok"
    }
  };
});

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
